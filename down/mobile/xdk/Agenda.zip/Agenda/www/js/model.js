var db;
var dataset;

function initDatabase() {
    console.debug('called initDatabase()');

    try {
        if (!window.openDatabase) {
            alert('não suportado');
        } else {
            var shortName = 'AgendaFin';
            var version = '1.0';
            var displayName = 'Agenda Financeira';
            var maxSizeInBytes = 65536;
            db = openDatabase(shortName, version, displayName, maxSizeInBytes);

            createTableIfNotExists();
        }
    } catch(e) {
        if (e == 2) {
            alert('Versáo inválida do banco de dados');
        } else {
            alert('Erro desconhecido ' + e);
        }
        return;
    }
}

function createTableIfNotExists() {
    console.debug('called createTableIfNotExists()');

    var sql = "CREATE TABLE IF NOT EXISTS Agenda (id INTEGER PRIMARY KEY AUTOINCREMENT, cliente TEXT NOT NULL, servico TEXT NOT NULL, data TEXT NOT NULL, valor TEXT NOT NULL, recebido TEXT NOT NULL)";

    db.transaction(
        function (transaction) {
            transaction.executeSql(sql, [], showRecords, handleErrors);
            console.debug('executeSql: ' + sql);
        }
    );
}

function insertRecord() {
    console.debug('called insertRecord()');

    var cliente = $('#cliente').val();
    var servico = $('#servico').val();
	var data = $('#data').val();
    var valor = $('#valor').val();
    var recebido = $('#recebido').val();

    var sql = 'INSERT INTO Agenda (cliente, servico, data, valor, recebido) VALUES (?, ?, ?, ?, ?)';

    db.transaction(
        function (transaction) {
            transaction.executeSql(sql, [cliente, servico, data, valor, recebido], showRecordsAndResetForm, handleErrors);
            transaction.executeSql(sql, [cliente, servico, data, valor, recebido], showRecords, handleErrors);
            console.debug('executeSql: ' + sql);
        }
    );
}

function selValor() {
    console.debug('called insertRecordIni()');

    db.transaction(
        function (transaction) {
            transaction.executeSql("SELECT sum(valor) from Agenda");			
	
            console.debug('executeSql insertRecordIni()');
        }
    );
}

function deleteRecord(id) {
    console.debug('called deleteRecord()');

    var txt;

    var r = confirm("Tem certeza?");
    if (r == true) {
        var sql = 'DELETE FROM Agenda WHERE id=?';
    
        db.transaction(
            function (transaction) {
                transaction.executeSql(sql, [id], showRecords, handleErrors);
                console.debug('executeSql: ' + sql);
                alert('Excluído com sucesso!');
            }
        );

        resetForm();

    } else {
        alert("Exclusão cancelada!");
    }
    
}

function updateRecord() {
    console.debug('called updateRecord()');

	var cliente = $('#cliente').val();
    var servico = $('#servico').val();
    var data = $('#data').val();
    var valor = $('#valor').val();
    var recebido = $('#recebido').val();
    var id = $("#id").val();

    var sql = 'UPDATE Agenda SET cliente=?, servico=?, data=?, valor=?, recebido=? WHERE id=?';

    db.transaction(
        function (transaction) {
            transaction.executeSql(sql, [cliente, servico, data, valor, recebido, id], showRecordsAndResetForm, handleErrors);
            console.debug('executeSql: ' + sql);
        }
    );
}

function dropTable() {
    console.debug('called dropTable()');

    var sql = 'DROP TABLE Agenda';

    db.transaction(
        function (transaction) {
            transaction.executeSql(sql, [], showRecords, handleErrors);
        }
    );
    resetForm();
	//insertRecordIni();    

    initDatabase();
}

function loadRecord(i) {
    console.debug('called loadRecord()');

    var item = dataset.item(i);

	$('#cliente').val(item['cliente']);
    $('#servico').val(item['servico']);
    $('#data').val(item['data']);	
    $('#valor').val(item['valor']);	
    $('#recebido').val(item['recebido']);	
    $('#id').val(item['id']);
}

function resetForm() {
    console.debug('called resetForm()');

	$('#cliente').val(item['cliente']);
    $('#servico').val(item['servico']);
    $('#data').val(item['data']);	
    $('#valor').val(item['valor']);	
    $('#recebido').val(item['recebido']);	
    $('#id').val('');
}

function showRecordsAndResetForm() {
    console.debug('called showRecordsAndResetForm()');

    resetForm();
    showRecords();
}

function handleErrors(transaction, error) {
    console.debug('called handleErrors()');
    console.error('error ' + error.message);

    alert(error.message);
    return true;
}

function showRecords() {
    console.debug('called showRecords()');

    var sql = "SELECT * FROM Agenda ORDER BY cliente ASC";

    db.transaction(
        function (transaction) {
            transaction.executeSql(sql, [], renderRecords, handleErrors);
        }
    );
}

function renderRecords(transaction, results) {
    console.debug('called renderRecords()');

    html = '';
    $('#results').html('');

    dataset = results.rows;
    
    if (dataset.length > 0) {
        //html = html + '<br/><br/>';
		
        html = html + '<table class="table table-bordered">';
        html = html + '  <tbody>';		

        for (var i = 0, item = null; i < dataset.length; i++) {
            item = dataset.item(i);

            html = html + '    <tr>';
            html = html + '      <td>' + item['cliente'] + '</td>';
            html = html + '      <td>';
            html = html + '        <a class="btn btn-primary btn-mini" title="Mostrar Detalhes" href="#cadastrar" onClick="loadRecord(' + i + ');"><b>M</td> <td></a>';
            html = html + '        <a class="btn btn-danger btn-mini"  title="Excluir este" href="#" onClick="deleteRecord(' + item['id'] + ');"><b>E</a>';
            html = html + '      </td>';
            html = html + '    </tr>';
        }

        html = html + '  </tbody>';
        html = html + '</table>';

        $('#results').append(html);
    }
}

function updateCacheContent(event) {
    console.debug('called updateCacheContent()');
    window.applicationCache.swapCache();
}

$(document).ready(function () {
    window.applicationCache.addEventListener('updateready', updateCacheContent, false);
    initDatabase();
});
