var db;
var dataset;

function initDatabase() {
    console.debug('called initDatabase()');

    try {
        if (!window.openDatabase) {
            alert('não suportado');
        } else {
            var shortName = 'DnocsAgenda';
            var version = '1.0';
            var displayName = 'Agenda do DNOCS';
            var maxSizeInBytes = 65536;
            db = openDatabase(shortName, version, displayName, maxSizeInBytes);

            createTableIfNotExists();
        }
    } catch(e) {
        if (e == 2) {
            alert('Versáo inválida do banco de dados');
        } else {
            alert('Erro desconhecido ' + e);
        }
        return;
    }
}

function createTableIfNotExists() {
    console.debug('called createTableIfNotExists()');

    var sql = "CREATE TABLE IF NOT EXISTS Agenda (id INTEGER PRIMARY KEY AUTOINCREMENT, setor TEXT NOT NULL, nome TEXT, fone TEXT)";

    db.transaction(
        function (transaction) {
            transaction.executeSql(sql, [], showRecords, handleErrors);
            console.debug('executeSql: ' + sql);
        }
    );
}

function insertRecord() {
    console.debug('called insertRecord()');

    var setor = $('#setor').val();
    var nome = $('#nome').val();
	var fone = $('#fone').val();

    var sql = 'INSERT INTO Agenda (setor, nome, fone) VALUES (?, ?, ?)';

    db.transaction(
        function (transaction) {
            transaction.executeSql(sql, [setor, nome, fone], showRecordsAndResetForm, handleErrors);
            //transaction.executeSql(sql, [setor, nome, fone], showRecords, handleErrors);
            console.debug('executeSql: ' + sql);
        }
    );
}

function insertRecordIni() {
    console.debug('called insertRecordIni()');

    db.transaction(
        function (transaction) {
            transaction.executeSql("INSERT INTO Agenda (setor, nome, fone) VALUES ('Diretor Geral', 'Walter Gomes de Sousa', '5206 e 5109')");		
            transaction.executeSql("INSERT INTO Agenda (setor, nome, fone) VALUES ('Chefe de Gabinete', 'Raquel Cristina Batista Vieira Pontes', '5201')");
            transaction.executeSql("INSERT INTO Agenda (setor, nome, fone) VALUES ('Secretaria Adm DG', 'José Marques', '5272')");
            transaction.executeSql("INSERT INTO Agenda (setor, nome, fone) VALUES ('CGPE', 'José Alberto', '5148 e 5161')");
            transaction.executeSql("INSERT INTO Agenda (setor, nome, fone) VALUES ('Comunic Social', 'José Cleyton', '5121')");
            transaction.executeSql("INSERT INTO Agenda (setor, nome, fone) VALUES ('Assessoria do DG', 'Maria Vilma', '5205')");
            transaction.executeSql("INSERT INTO Agenda (setor, nome, fone) VALUES ('Planej e Orçamento', 'Maria Aucineide', '5250 e 5253')");
            transaction.executeSql("INSERT INTO Agenda (setor, nome, fone) VALUES ('CGE', 'João Otávio', '5103')");
            transaction.executeSql("INSERT INTO Agenda (setor, nome, fone) VALUES ('Serv Informática', 'Antônio Gutemberg', '5175')");
            transaction.executeSql("INSERT INTO Agenda (setor, nome, fone) VALUES ('Modern Document', 'Lúcia Piancó', '5296')");
            transaction.executeSql("INSERT INTO Agenda (setor, nome, fone) VALUES ('Serv Planejam', 'Josimeuba Josino', '5285')");
            transaction.executeSql("INSERT INTO Agenda (setor, nome, fone) VALUES ('Monitor e Convênio', 'Elda Maria', '5333')");
            transaction.executeSql("INSERT INTO Agenda (setor, nome, fone) VALUES ('CEST/AL', 'Paulo Maia', '82-3421-2350')");	
            transaction.executeSql("INSERT INTO Agenda (setor, nome, fone) VALUES ('CEST/BA', 'Mahomed Mahmud', '5272')");
            transaction.executeSql("INSERT INTO Agenda (setor, nome, fone) VALUES ('CEST/PB', 'Avanir Ponce', '83-3214-7819')");
            transaction.executeSql("INSERT INTO Agenda (setor, nome, fone) VALUES ('CEST/MG', 'Adauto Marques', '38-3221-6192')");
            transaction.executeSql("INSERT INTO Agenda (setor, nome, fone) VALUES ('CEST/PE', 'Emílio Duarte', '81-3441-7844')");
            transaction.executeSql("INSERT INTO Agenda (setor, nome, fone) VALUES ('CEST/PI', 'Antônio Djalma', '86-3222-4816')");
	        transaction.executeSql("INSERT INTO Agenda (setor, nome, fone) VALUES ('CEST/RN', 'José Eduardo', '84-3212-5304')");
            transaction.executeSql("INSERT INTO Agenda (setor, nome, fone) VALUES ('CEST/SE', 'Aécio Chaves', '79-3215-4739')");
            transaction.executeSql("INSERT INTO Agenda (setor, nome, fone) VALUES ('Serv Transporte', 'Benício Elias', '3223-0611')");
            transaction.executeSql("INSERT INTO Agenda (setor, nome, fone) VALUES ('Setor Arquivo', 'Raphael Felipe', '3283-3311')");
            transaction.executeSql("INSERT INTO Agenda (setor, nome, fone) VALUES ('Pesq Pentecoste', 'Ageu Barros', '3352-1235')");
            transaction.executeSql("INSERT INTO Agenda (setor, nome, fone) VALUES ('Castanhão', 'José Ulysses', '88-9904-0400')");
            transaction.executeSql("INSERT INTO Agenda (setor, nome, fone) VALUES ('ASSECAS', 'ASSECAS', '3252-2409')");
            transaction.executeSql("INSERT INTO Agenda (setor, nome, fone) VALUES ('ASDEC', 'ASDEC', '3219-5392/5393')");			
            transaction.executeSql("INSERT INTO Agenda (setor, nome, fone) VALUES ('Banco Brasil', 'Banco Brasil', '3223-0259')");
            transaction.executeSql("INSERT INTO Agenda (setor, nome, fone) VALUES ('Caixa', 'Caixa', '3206-3050')");			
            transaction.executeSql("INSERT INTO Agenda (setor, nome, fone) VALUES ('Guarita Estacion', 'Guarita', '5324')");			
            transaction.executeSql("INSERT INTO Agenda (setor, nome, fone) VALUES ('CGE/IN', 'Fátima Ramalho', '5110')");	
            transaction.executeSql("INSERT INTO Agenda (setor, nome, fone) VALUES ('Protocolo', 'Doralice Ramos', '5155')");	
            transaction.executeSql("INSERT INTO Agenda (setor, nome, fone) VALUES ('Rede', 'Alexandre Muzzio', '5277')");	
            transaction.executeSql("INSERT INTO Agenda (setor, nome, fone) VALUES ('Sala do Cidadão', 'Ana Lúcia', '5171')");	
            transaction.executeSql("INSERT INTO Agenda (setor, nome, fone) VALUES ('Portaria Caixa', 'Portaria Caixa', '5107')");	
            transaction.executeSql("INSERT INTO Agenda (setor, nome, fone) VALUES ('Portaria BB', 'Portaria BB', '5320')");	
            transaction.executeSql("INSERT INTO Agenda (setor, nome, fone) VALUES ('Central PABX', 'Regina Célia', '3391-5100')");	
            transaction.executeSql("INSERT INTO Agenda (setor, nome, fone) VALUES ('Biblioeca', 'Anésia Torres', '5111')");	
            transaction.executeSql("INSERT INTO Agenda (setor, nome, fone) VALUES ('Capacitação', 'Mário Henrique', '5518')");	
            transaction.executeSql("INSERT INTO Agenda (setor, nome, fone) VALUES ('Ouvidoria', 'Evandro Sérgio', '5198')");	
            transaction.executeSql("INSERT INTO Agenda (setor, nome, fone) VALUES ('Eletricistas', 'Francisco Gois', '5355')");			
            transaction.executeSql("INSERT INTO Agenda (setor, nome, fone) VALUES ('Auditório', 'Auditório', '5353')");			
            transaction.executeSql("INSERT INTO Agenda (setor, nome, fone) VALUES ('CEST/CE', 'Francisco Rogério Gomes Leite', '5300 e 5302')");			
            transaction.executeSql("INSERT INTO Agenda (setor, nome, fone) VALUES ('Auditoria Interna', 'Nadedja Fernandes Cavalcante', '5219')");			
	
            console.debug('executeSql insertRecordIni()');
        }
    );
}

function deleteRecord(id) {
    console.debug('called deleteRecord()');

    var txt;

    var r = confirm("Tem certeza?");
    if (r == true) {
        var sql = 'DELETE FROM Agenda WHERE id=?';
    
        db.transaction(
            function (transaction) {
                transaction.executeSql(sql, [id], showRecords, handleErrors);
                console.debug('executeSql: ' + sql);
                alert('Excluído com sucesso!');
            }
        );

        resetForm();

    } else {
        alert("Exclusão cancelada!");
    }
    
}

function updateRecord() {
    console.debug('called updateRecord()');

	var setor = $('#setor').val();
    var nome = $('#nome').val();
    var fone = $('#fone').val();
    var id = $("#id").val();

    var sql = 'UPDATE Agenda SET setor=?, nome=?, fone=? WHERE id=?';

    db.transaction(
        function (transaction) {
            transaction.executeSql(sql, [setor, nome, fone, id], showRecordsAndResetForm, handleErrors);
            console.debug('executeSql: ' + sql);
        }
    );
}

function dropTable() {
    console.debug('called dropTable()');

    var sql = 'DROP TABLE Agenda';

    db.transaction(
        function (transaction) {
            transaction.executeSql(sql, [], showRecords, handleErrors);
        }
    );
    resetForm();
	insertRecordIni();    

    initDatabase();
}

function loadRecord(i) {
    console.debug('called loadRecord()');

    var item = dataset.item(i);

	$('#setor').val(item['setor']);
    $('#nome').val(item['nome']);
    $('#fone').val(item['fone']);	
    $('#id').val(item['id']);
}

function resetForm() {
    console.debug('called resetForm()');

    $('#setor').val('');
    $('#nome').val('');
    $('#fone').val('');
    $('#id').val('');
}

function showRecordsAndResetForm() {
    console.debug('called showRecordsAndResetForm()');

    resetForm();
    showRecords();
}

function handleErrors(transaction, error) {
    console.debug('called handleErrors()');
    console.error('error ' + error.message);

    alert(error.message);
    return true;
}

function showRecords() {
    console.debug('called showRecords()');

    var sql = "SELECT * FROM Agenda ORDER BY setor ASC";

    db.transaction(
        function (transaction) {
            transaction.executeSql(sql, [], renderRecords, handleErrors);
        }
    );
}

function renderRecords(transaction, results) {
    console.debug('called renderRecords()');

    html = '';
    $('#results').html('');

    dataset = results.rows;
    
    if (dataset.length > 0) {
        //html = html + '<br/><br/>';
		
        html = html + '<table class="table table-bordered">';
        html = html + '  <tbody>';		

        for (var i = 0, item = null; i < dataset.length; i++) {
            item = dataset.item(i);

            html = html + '    <tr>';
            html = html + '      <td>' + item['setor'] + '</td>';
            //html = html + '      <td>' + item['nome'] + '</td>';
            //html = html + '      <td>' + item['fone'] + '</td>';
            html = html + '      <td>';
            html = html + '        <a class="btn btn-primary btn-mini" title="Mostrar Detalhes" href="#cadastrar" onClick="loadRecord(' + i + ');"><b>M</td> <td></a>';
            html = html + '        <a class="btn btn-danger btn-mini"  title="Excluir este" href="#" onClick="deleteRecord(' + item['id'] + ');"><b>E</a>';
            html = html + '      </td>';
            html = html + '    </tr>';
        }

        html = html + '  </tbody>';
        html = html + '</table>';

        $('#results').append(html);
    }
}

function updateCacheContent(event) {
    console.debug('called updateCacheContent()');
    window.applicationCache.swapCache();
}

$(document).ready(function () {
    window.applicationCache.addEventListener('updateready', updateCacheContent, false);
    initDatabase();
});
